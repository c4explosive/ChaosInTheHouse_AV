	GAME MAKER RESOURCE PACK 05

This zip file contains over 16 Game ID Packs,
each consisting of Game Loaders, Highscore Screens,
and Icons, all created by John Hempstead,
Morphosis Enter-Active.

