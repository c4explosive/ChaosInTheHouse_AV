	GAME MAKER RESOURCE PACK 01

This zip file contains some additional
resources (sounds, sprites, tiles) for Game 
Maker version 7.

This resource pack will install the following:

SPRITES: 
Contains a collection of freeware (animated) sprites that
can be used in your games. The following people donated sprites:
  - Primalmania, see http://primalmania.fateback.com/
  - Morphosis, see http://www.geocities.com/morphosisgames/
  - Billy McQuown

BACKGROUNDS:
Contains a number of freeware background images that you
can use in your games. It also contains a number of tile sets:
  - platform1.bmp and platform2.bmp are tile sets for platform 
    games. They are copyright Ari Feldman. See the website      
    http://www.arifeldman.com/ for more information.
  - rpg1.bmp and rpg2.bmp are useful for strategy games. They are
    reduced version of the sets created by Hermann Hillmann as part
    of the charpack. See the charpack website 
    http://www.vbexplorer.com/charpack1.asp for more information.
  - km.bmp, pk.bmp and ps.bmp were created by e.m.b.u. See 
    http://www.embu.cjb.net for conditions of use and other tile sets.

SOUNDS:
Contains a number of freeware sound effects that you can use
in your games.

Note that most of these resources have been taken 
from freeware collections. This means that you
can use them in freeware games but this is not 
clear for commercial games.
