====================================================
|    ###    ########   #######  ##     ## ######## |
|   ## ##   ##     ## ##     ## ##     ##    ##    |
|  ##   ##  ##     ## ##     ## ##     ##    ##    |
| ##     ## ########  ##     ## ##     ##    ##    |
| ######### ##     ## ##     ## ##     ##    ##    |
| ##     ## ##     ## ##     ## ##     ##    ##    |
| ##     ## ########   #######   #######     ##    |
====================================================

This zip file should contains 10 midi files composed by me and a readme. The midis are suitable for role playing or adventure type game but can be use for others if as seem appropriate. Each of the files was given a name depend on the theme and the mood of the tune. Please continue to read on for more importain info.

==============================================================
| ##       ####  ######  ######## ##    ##  ######  ######## |
| ##        ##  ##    ## ##       ###   ## ##    ## ##       |
| ##        ##  ##       ##       ####  ## ##       ##       |
| ##        ##  ##       ######   ## ## ##  ######  ######   |
| ##        ##  ##       ##       ##  ####       ## ##       |
| ##        ##  ##    ## ##       ##   ### ##    ## ##       |
| ######## ####  ######  ######## ##    ##  ######  ######## |
==============================================================

The midis can be use in your programs or games royalties free without any charge. A little bit of credits to me would be nice, but are not obligated to. If you would like to give something in return to me, just email me with a short message saying you like them, that's all.

====================================================================
|  ######   #######  ##    ## ########    ###     ######  ######## |
| ##    ## ##     ## ###   ##    ##      ## ##   ##    ##    ##    |
| ##       ##     ## ####  ##    ##     ##   ##  ##          ##    |
| ##       ##     ## ## ## ##    ##    ##     ## ##          ##    |
| ##       ##     ## ##  ####    ##    ######### ##          ##    | 
| ##    ## ##     ## ##   ###    ##    ##     ## ##    ##    ##    |
|  ######   #######  ##    ##    ##    ##     ##  ######     ##    |
====================================================================

Feel free to write to me if you have any question or request. Also, please visit my website if you have some time.

Email: Greendragon25@yahoo.com
Website: http://www.gmegamix.cjb.net

-----------------------------------------------

That's all, have a nice day. - Dung Truong (DT)