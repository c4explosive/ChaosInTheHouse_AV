	GAME MAKER RESOURCE PACK 02

This zip file contains some additional
resources (example games, sounds, sprites,
tiles) for Game Maker version 7.

This resource pack was composed by True Predator.
It installs a number of backgrounds, midi sounds,
sprites, and strips.

Note that most of these resources have been taken 
from freeware collections. This means that you
can use them in freeware games but this is not 
clear for commercial games.
