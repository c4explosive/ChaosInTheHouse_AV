BEGIN TRANSACTION;
CREATE TABLE "comidas" (
	`nombre`	BLOB NOT NULL UNIQUE,
	`dir_imagen`	BLOB NOT NULL,
	`ingredientes`	BLOB,
	`prep`	BLOB,
	`alergias`	BLOB,
	`caracteristicas`	BLOB,
	PRIMARY KEY(`nombre`)
);
INSERT INTO `comidas` VALUES ('Sopa De Pollo','sopa_de_pollo.gif','Ingredientes:\n
Cualquier pieza de pollo sin piel
6 a 8 tazas de agua
3 papas medianas (opcional)
1 zanahoria mediana (opcional)
1 cebolla mediana (al gusto)
Algunas hojas de hierbabuena
1 pimiento
Hojas de perejil
Hojas de cilantro
1 tallo y hojas de apio
Oregano en polvo
Hojas de laurel
Sal
Pimienta
Fideos para sopa (opcional)','\n\nPreparacion:

En una olla grande pon a hervir las piezas de pollo en aproximadamente 2 litros de agua. Deja que hierva durante unos 15 minutos. Durante este tiempo debes estar pendiente de retirarle constantemente la espuma que se acumula en la superficie.

Agrega la cebolla| pimiento y aji previamente picados.

Seguidamente ponle sal| pimienta| oregano y un par de hojas de laurel. Estas medidas son subjetivas y dependen de tu gusto. Comienza con poca cantidad y puedes aumentarla posteriormente.','N/A','comida criolla
');
INSERT INTO `comidas` VALUES ('Arroz Blanco','arroz_blanco.gif','Ingredientes:\n
1 taza de arroz blanco
2 tazas de agua
1 cucharadita de sal
1 cucharada de aceite vegetal','\n\nPreparacion:
Busca una olla mediana en buen estado para hacer el arroz. Agrega el arroz blanco| las 2 tazas de agua| la sal y el aceite vegetal| todo de una vez. Revuelve un poco solo en una oportunidad y ya.

Pon la olla a fuego alto. Va a comenzar a hervir| perfecto| no hagas nada.

Al cabo de unos pocos minutos (no mas de 5)| se va a secar el agua por completo. Cuando veas que esto sucede| mas precisamente| cuando veas que esta a punto de dejar de botar burbujas de agua sobre la superficie del arroz| baja el fuego al minimo y tapa la olla.

Deja que transcurran 15 minutos| destapa y prueba el grano. Ya deberia estar listo. Si no lo esta (recuerda que algunas cocinas son menos potentes)| vuelve a tapar por otros 5 minutos. Si el grano ya esta| apaga y retira de la estufa| esto es criticamente importante si tu cocina es electrica| el calor podria fastidiarlo todo.','N/A','comida criolla');
INSERT INTO `comidas` VALUES ('Pollo Asado','pollo_asado.gif','Ingredientes:\n 
1.5 o mas kg de pollo 
1 limon
60 ml. aceite de oliva virgen extra
1 cucharada sopera 
3 dientes de ajo
Sal y pimienta negra recien molida (al gusto)
4 papas (1 papa por persona)','\n\nPreparacion:\n 

Precalienta el horno a 200 grados centigrados.
Primero debes limpiar bien el pollo. Una vez limpio secalo| no debe tener agua al momento de meterlo al horno.
Condimenta el pollo con el tomillo| oregano| sal y pimienta a tu antojo. Agregale tambien un chorrito de aceite de oliva y frotalo bien para que quede todo untado tanto por las especias como por el aceite. No olvides hacer esto tambien con el interior del pollo.
Pon el pollo en una bandeja donde quepa comodamente y cubre con papel aluminio.
Mete el pollo en el horno y cocina por 45 minutos.
Transcurrido este tiempo retira el papel aluminio y voltea el pollo con cuidado. 
Deja que se cocine otra media hora. Llegado este punto| y dependiendo de tu horno| el pollo podria estar asado. Puedes chequear esto introduciendole un palito en la carne para ver si sale sangre de su interior. Si tienes dudas deja cocinar unos minutos mas| siempre destapado.
Una vez listo| apaga el horno y dejalo reposar 10 minutos.','N/A','comida criolla');
INSERT INTO `comidas` VALUES ('Porotos Rojos','porotos_rojos.gif','Ingredientes:\n 
Porotos rojos secos','\n\nPreparacion:\n Esparce los granos secos de frijol rojo sobre una bandeja para hornear limpia. Tamizalos con las manos para eliminar la suciedad| piedras chicas u otros desechos. Transfiere los granos a un colador y enjuagalos con agua fria.

Coloca los frijoles enjuagados en una olla grande. Agrega tres tazas de agua fria por cada taza de granos o unos 10 vasos de agua para un paquete de 1 libra (453 gr) de frijoles rojos secos. Permite que los frijoles se queden en remojo durante la noche| al descubierto.

Escurre el agua de los frijoles con un colador| vertiendo el contenido de la olla. Enjuagalos con agua fria y luego regresalos a la olla. Cubre los frijoles con agua fresca y colocalos en la estufa.

Pon a hervir el agua y los frijoles a fuego medio-alto. Reduce el fuego a medio-bajo y cocina a fuego lento por aproximadamente 1 hora y media. Retira uno de los granos para verificar la coccion; muerdelo o pellizcalo para ello.

Si es necesario| continua cocinando los frijoles durante 15 minutos. Comprueba de nuevo el punto de coccion y repite esto cada 15 minutos hasta que esten tan tiernos como desees. Como regla general| los frijoles rojos normalmente necesitan alrededor de dos horas para cocinarse.

Retira los frijoles rojos del fuego| agrega sal y pimienta a gusto y sirve inmediatamente. Almacena las sobras en el refrigerador hasta cuatro dias antes de desechar cualquier porcion no utilizada.','N/A','comida criolla');
INSERT INTO `comidas` VALUES ('Pollo A La Naranja','pollo_a_la_naranja.gif','Ingredientes:\n
600 g de filete de pechuga de pollo sin piel
sal y pimienta al gusto
2 cucharadas de aceite

-Para la salsa:\n
2 cucharadas de agua
2 cucharadas de fecula de maiz
1/4 de taza de salsa de soya
1/2 taza de jugo de naranja natural
1/4 de taza de miel de abeja
3 cucharadas de vinagre de arroz
1 cucharadita de picante tipo sriracha
2 cucharadas de ralladura de cascara de naranja
2 cucharadas de jengibre rallado
2 dientes de ajo picados

-Para servir:\n
Arroz blanco para servir
1 tallo de cebollines ssegados','\n\nPreparacion:

Corte el pollo en trozos y salpimiente.

En un wok| caliente el aceite y agregue el pollo en porciones. Deje que se cocine.

En un tazon| revuelva el agua y la fecula. Agregue la salsa de soya| el jugo de naranja| la miel de abeja| el vinagre de arroz| el picante y la ralladura de naranja. Incorpore el jengibre y el ajo. Mezcle muy bien.

Incorpore al wok y mezcle con el pollo. Deje que la salsa se reduzca por completo.

Sirva sobre arroz blanco y decore con cebollino.','Alergias:\n
Jengibre
Picante
Maiz','comida asiatica');
INSERT INTO `comidas` VALUES ('Pollo Al Curry','pollo_al_curry.gif','Ingredientes:\n
2 pechugas de pollo
1 vaso de nata para cocinar
1 cebolla grande
2 cucharadas de curry picante
Almendras picadas
Cilantro picado
Sal| pimienta y comino
Aceite de oliva
Canela (opcional)','\n\nPreparacion:

Agregue sal y pimienta a las pechugas de pollo y cortelas en cuadros de dos dedos de grosor. En una sarten con aceite de oliva| agregue los cuadros recien cortados y deje que se doren por todos lados.

Aparte pique la cebolla. Pongalas a freir en una sarten a fuego medio durante 5 minutos y retirelas en un plato. Agregue la nata| dos cucharadas colmadas de curry| una pizca de comino y canela al gusto (se puede omitir) y mezcle todo bien hasta que no hayan grumos.

Deje que la salsa se reduzca durante 10 minutos| lo suficiente para que el pollo termine de hacerse por dentro y la salsa espese. Agregar sal y pimienta al gusto. Espolvorear un poco de almendra picada y cilantro. Servir.','Alergias:\n
Picante
Curry
Almendras
Comino','comida asiatica');
INSERT INTO `comidas` VALUES ('Ensalada De Tomate','ensalada_de_tomate.gif','Ingredientes:\n
3 tomates rojos duros
3 cucharadas de aceite de oliva
1 o 2 cucharadas de vinagre blanco
1 cucharadita de ajo picado fino
2 cucharadas de perejil picado fino
2 cucharadas de albahaca fresca picada fina
Sal y pimienta al gusto','\n\nPreparacion:

Parta los tomates en rodajas.

Mezcle con el resto de ingredientes y deje reposar.
','Alergias:\n
Albahaca','comida italiana');
INSERT INTO `comidas` VALUES ('Paella De Mariscos','paella_de_mariscos.gif','Ingredientes:\n
Aceite de oliva
1/2 kg de camarones frescos pelados y limpios (reserve las cascaras)
1/2 kg de mejillones limpios
1/2 kg de almejas limpias
1 cebolla en cuadritos
1/2 chile dulce
1 tomate mediano
2 dientes de ajo
1/2 kg de calamares
Sal y pimienta
2.5 tazas de arroz arborio
5 tazas de caldo de pescado o de verduras
Hebras de azafran
1/2 taza de guisantes
1 rollito de perejil','\n\nPreparacion:

En una olla caliente ponga un chorrito de aceite de oliva y sofria las cascaras de los camarones hasta que tomen un color rojizo. Agregue el caldo y deje hervir durante 10 minutos. Cuele el caldo y reserve.

Limpie los mejillones y las almejas con abundante agua.

Corte la cebolla en cuadritos| el igual que el chile dulce y el tomate. Triture los dientes de ajo. En una paellera o un sarten grande| sofria estos ingredientes con un chorrito de aceite de aliva y unas pizcas de sal y pimienta.

Agregue el arroz y sofria hasta que cambie a un color nacar. Incorpore los mejillones y las almejas y revuelva bien.

Agregue el caldo y el azafran. Revuelva bien y deje cocinar sin revolver por unos minutos.

Cuando aun quede un poco de caldo en el sarten| agregue los guisantes| los camarones y el perejil. Rectifique la sazon.

Tape con papel aluminio y deje cocinar hasta que se seque un poco mas.

Retire del fuego| tape con el papel aluminio y deje reposar por unos minutos antes de servir.
','Alergias:\n
Mariscos
Azafaran','comida espanhola');
INSERT INTO `comidas` VALUES ('Smoothie De Frutos Rojos','smoothie_de_frutos_rojos.gif','Ingredientes:\n
250 g de fresas
125 g de frambuesas congeladas
125 g de moras congeladas
300 ml de agua','\n\nPreparacion:

Lave bien las frutas.

Coloque las frutas en una licuadora junto con el agua y triturelas hasta que obtenga una textura suave y homogenea.','Alergias:\n
Frutos rojos','N/A');
INSERT INTO `comidas` VALUES ('Mousse De Chocolate Blanco','mousse_de_chocolate_blanco.gif','Ingredientes:\n
2 cucharadas de ron blanco
250 g de nata
1 naranja
1 limon
1 huevo
150 g de chocolate blanco
1 cucharada de azucar','\n\nPreparacion:

Rallar la naranja y exprimir el limon. Cortar en trozos el chocolate blanco. Colocarlo en una vasija junto con la nata| la ralladura de naranja y el ron blanco. Calentar durante 2 minutos.

Batir y colocar en la nevera durante 2 horas. Batir la clara del huevo a punto de nieve y agregar el azucar poco a poco. Agregar una cucharadita de zumo de limon| mezclar cuidadosamente con la mezcla anterior y ponerlo a enfriar hasta el momento de servir.','Alergias:\n
Chocolate','comida francesa');
INSERT INTO `comidas` VALUES ('Ensalada Caprese','ensalada_caprese.gif','Ingredientes:\n
2 tomates perita
150 g de queso mozzarella
20 hojas de albahaca fresca
1 cucharadita de sal
1 pizca de pimienta negra
1 cucharada sopera de aceite de oliva extra virgen
','\n\nPreparacion:

Cortar los tomates en rodajas| ni muy finas ni muy gruesas. Reservarlas.

Cortar el queso mozzarella en rodajas similares a las del tomate. Reservarlas.

Realizar una preparacion con unas hojitas de albahaca fresca picada| aceite de oliva extra virgen| sal y pimienta negra.

Para la presentacion de la ensalada| tomar un plato y arreglar los ingredientes intercalando una rodaja de tomate| una de mozzarella| una de albahaca y asi sucesivamente. Aderezar con la preparacion realizada con anterioridad y espolvorear con un toque de pimienta en grano recien molida para decorar.','Alergias:\n
Albahaca','comida italiana');
INSERT INTO `comidas` VALUES ('Pollo Al Ajillo','pollo_al_ajillo.gif','Ingredientes:\n
1.5 kg de pollo troceado
8 dientes de ajo
1 hoja de laurel
300 ml de vino blanco
1 ramita de romero fresco y tomillo al gusto
75 ml de aceite de oliva extra virgen
Sal y pimienta negra recien molida al gusto
Perejil o cilantro fresco picado para decorar
','\n\nPreparacion:

Agregar sal y pimienta a los trozos de pollo ligeramente.

En una cazuela ancha poner a calentar una cantidad abundante de aceite de oliva y echar los ajos sin pelar. Cocinarlos a fuego medio y no dejar que se quemen. La idea es que queden caramelizados y sirvan de aromatizante para el aceite. Retirarlos despues de unos 5 minutos y reservarlos.

Colocar los trozos de pollo en la cazuela con el aceite aromatizado con el ajo| junto con la hojita de laurel| la rama de romero y el tomillo.

El pollo debe quedar bien frito| dejarlo en de 15 a 20 minutos en el aceite. Darles vuelta para que queden tostados por todas partes.

Cuando este listo| retirar el exceso de aceite. Agregarles los ajos reservados y el vino. Seguir cocinando la carne hasta que el vino se haya reducido por completo.

Servir caliente con un poco de perejil o cilantro picado por encima.','Alergias:\n
Romero
Tomillo
Laurel','comida espanhola');
INSERT INTO `comidas` VALUES ('Albondigas','albondigas.gif','Ingredientes:\n
-Para las albondigas
500 g de carne picada
2 dientes de ajo
3 huevos
Harina para rebozar
Sal y pimienta
Tomillo|comino o romero (opcional)

-Para la salsa de tomate
2 dientes de ajo
1.5 kg de tomates
Sal y pimienta negra
Aceite','\n\nPreparacion:

En un bowl poner la carne picada| los dientes de ajo picados y los huevos. Echar sal y pimienta. Agregar otras especias al gusto| como comino| romero o tomillo. Mezclar con las manos hasta que quede una masa homogenea.

Tomar una pequenha porcion de la masa y darle forma de bolita| del tamanho maximo de una bola de golf. Despues reservar las bolitas en un plato hasta haber terminado de dar forma a toda la masa.

Una vez tenga todas las bolas hechas| hacerlas rodar una a una por un plato con harina. Una vez haya terminado con todas las albondigas| guardarlas en la nevera mientras prepara la salsa de tomate.

En una cazuela poner un chorrito de aceite a calentar. Despues agregar los dos dientes de ajo picados y dejar que doren durante un minuto.

Una vez dorados| agregar el tomate sin piel. Agregar sal y pimienta y dejar cocinar durante unos minutos| revolviendo constantemente hasta que el tomate quede triturado. Dejar cocinar a fuego lento duarnte media hora mas| mientras revuelve de vez en cuando.

Mientras se cocina la salsa| poner a freir las albondigas que han estado reposando en la nevera| en abundante aceite muy caliente. Freirlas durante un minuto hasta que se doren por fuera.

Una vez que esten fritas las albondigas y que la salsa de tomate haya estado 30 minutos cocinandose| agregar 1/2 cucharadita de tomillo (opcional) e introducir en salsa las albondigas. Revolver con una cuchara para que se mojen bien de salsa y dejar cocinar 5 minutos mas.','Alergias:\n
Tomillo
Comino
Romero','comida criolla');
INSERT INTO `comidas` VALUES ('Carne Guisada','carne_guisada.gif','Ingredientes:\n
600 g de carne para guisar (babilla)
1 cebolla grande
2 dientes de ajo
2 zanahorias
1 pimiento rojo
1 pimiento verde
4 o 6 champinhones grandes
1/4 de taza de harina
2 vasos de vino tinto
1/2 taza de tomate triturado
Aceite de oliva
Sal y pimienta al gusto','\n\nPreparacion:

Corte el ajo| la cebolla| la zanahoria y los pimientos en cuadritos mas pequenhos que la carne. En una cazuela colocar aceite de oliva y agregar las verduras. Dejarlas refreir.

Proceda a limpiar la carne| intentando que no queden tendones ni grasa. Cortarla en cuadrados de unos dos dedos de grosos y echarles sal y pimienta al gusto. Remover con las manos para que se integre.

Agregar en la cazuela con las verduras| los champinhones y la carne y dejar que se dore todo junto hasta que la carne este sellada.

Agregar el tomate y por ultimo el vino tinto. Revuelva. Tape la cazuela y deje cocinar durante 20 minutos. Sirva con arroz o papas.','Alergias:\n
Pimientos
Champinhones','comida criolla');
INSERT INTO `comidas` VALUES ('Smoothie De Papaya Y Chia','smoothie_de_papaya_y_chia.gif','Ingredientes:\n
1 taza de papaya en pedazos| fresca o congelada
1 taza de jugo de naranja
1 cucharada de semillas de chia','\n\nPreparacion:

Coloque todos los ingredientes en una licuadora y licue hasta obtener una mezcla homogenea.','N/A','N/A');
INSERT INTO `comidas` VALUES ('Risotto De Setas','risotto_de_setas.gif','Ingredientes:\n
200 g de arroz arborio
80 g de cebolla blanca
2 dientes de ajo
200 g de champinhones
500 ml de caldo de verduras
Aceite de oliva
1 pizca de sal y pimienta','\n\nPreparacion:

En una olla con aceite| agregar el aceite| saltear la cebolla y el ajo cortado finamente hasta que este blando.

Agregar el arroz y sofreir durante un minuto.

Agregar el caldo de verduras de a poco| revolviendo todo el tiempo hasta que el grano este al dente. Rectificar sabor con sal.

En otra olla| saltear los champinhones en aceite de oliva hasta que esten dorados y salpimentar. Si desea puede agregar otro tipo de setas al gusto.

Cuando al arroz le falten 5 minutos para estar| agregar los champinhones y mezclar todo muy bien.','Alergias:\n
Champinhones','comida italiana');
INSERT INTO `comidas` VALUES ('Lasagna','lasagna.gif','Ingredientes:\n
300 ml de salsa bechamel
12 laminas de pasta para lasanha
1 kg de carne molida
1 cebolla
2 dientes de ajo
400 g de tomate triturado
100 g de tomate frito (5 o 6 cucharadas)
50 ml de aceite de oliva
50 g de queso rallado
1 trozo de mantequilla
2 litros de agua
1 pizca de sal y pimienta negra molida','\n\nPreparacion:

Empiece por picar la cebolla y el ajo finamente. En  un sarten con aceite caliente a fuego medio| haga un sofrito con estos dos ingredientes. Sofreir hasta que empiece a ponerse todo transparente. Si ve que la cebolla o el ajo empiezan a dorarse agregue un poco de agua y revuelva bien.

Agregue la carne a la sarten y revuelva bien de manera que se cocine toda la carne por igual. El tiempo de coccion sera de unos 20 a 30 minutos.

Pasado este tiempo| incorpore el tomate triturado| el tomate frito y sazone con una pizca de de sal y pimienta. Mezcla bien y sube la llama a fuego alto para cocinar el conjunto por unos 5 minutos mas.

Cuando vea que la carne esta en su punto| pruebe la sazon y corrija si es necesario. Reserva la carne para el relleno de la lasanha aparte.

Con la carne ya lista| puede cocinar las laminas de pasta. Para ello| caliente suficiente agua con una pizca de sal y siga las instrucciones del fabricante| por lo general con unos 8 minutos de coccion es suficiente.

Para montar la lasagna de carne| engrase una fuente para horno con mantequilla y empiece colocando una capa de pasta en la base. Luego coloca una capa del relleno de carne y termina con una porcion de salsa bechamel.

Repita el procedimiento hasta terminar con los ingredientes| el resultado deberia ser de unas tres capas de pasta y carne. Termine la lasanha con una capa de pasta| encima bechamel y por ultimo una capa gruesa de queso.

Cocine la lasanha casera en el horno a 180 grados Celsius y con el grill puesto hasta que el queso gratine. Una vez lista| retire del horno y deje reposar unos 10 minutos para que al cortar las porciones no se desarme la lasagna.

','N/A','comida italiana');
INSERT INTO `comidas` VALUES ('Salmon Ahumado','salmon_ahumado.gif','Ingredientes:\n
500 g de salmon
1 cucharadita de aceite de oliva
1 cucharada sopera de sal
1 taza de arroz blanco
1 manojo de laurel fresco
1 manojo de tomillo fresco
1 cucharada sopera de oregano fresco
1 pizca de pimienta negra','\n\nPreparacion:

Cubrir con papel aluminio la superficio deuna sarten y adicionar el arroz crudo junto con las hierbas: laurel| oregano y tomillo.

Sazonar el filete de salmon con el aceite de oliva| pimienta y sal al gusto. Untarlo bien por todos lados.

Colocar el salmon encima de una parrilla metalica y llevar el sarten a fuego medio-bajo.

Cuando el arroz y las hierbas empiecen a soltar humo| tapar la pieza de salmon para que el humo cocine toda la carne. Dejar la pieza de salmon durante unos 20 a 30 minutos para que el humo penetre bien por todas partes. Si se quiere se puede voltear por lado y lado| para ahumar de forma mas pareja.','Alergias:\n
Tomillo
Laurel','N/A');
INSERT INTO `comidas` VALUES ('Arroz Con Pollo','arroz_con_pollo.gif','Ingredientes:\n
1 pollo troceado
2 cucharaditas de vinagre
4 cucharaditas de salsa china
3 cucharaditas de sal
1 cucharadita de pimienta
1 tomate maduro
3 ajies verdes
1/2 cebolla
3 dientes de ajo
550 g de arroz
1 taza de oliva verde sin hueso
1 taza de pimenton
1 taza de vegetales mixtos
1 lata de salsa de tomate','\n\nPreparacion:

Coloque el pollo previamente sazonado con sal| pimienta| salsa china y vinagre en una paila a sofreir en 2 cucharaditas de aceite.

Agregue la cebolla| los ajies y el tomate y revuleva hasta que el pollo se vea medio cocido por fuera.

Luego adicione la salsa de tomate y agregue 2 medidas de agua de la lata y deje cocinar a fuego lento por 20 minutos.

Luego retire las presas del pollo de la salsa y adiciona el arroz previamente lavado.

Verifique que la salsa este pulgada y media por encima del arroz. Agregue agua si es necesario y pruebe el punto de sal a su gusto.

Tan pronto el arroz este sin agua| tapelo y pongalo a fuego lento por 20 minutos mas. Luego destape| revuelva y adicione las presas de pollo junto con el resto de los ingredientes.

Vuelva a taparlo por 20 minutos mas. Revuleva para mezclar los ingredientes y sirva a su gusto.','N/A','comida criolla');
INSERT INTO `comidas` VALUES ('Carne Asada','carne_asada.gif','Ingredientes:\n
1 lomo redondo de 2 kg
8 dientes de ajo
1 cucharada de sal
1/2 cucharadita de oregano
2 hojas de laurel
2 cucharadas de vinagre
1/2 taza de aceite','\n\nPreparacion:

Haga dos incisiones a lo largo del lomo.

Machaque los ajos con sal y oregano y frote con esta preparacion la carne.

Caliente aceite y dorela. Agreguele las hojas de laurel y vinagre. Tapela muy bien y cocine a fuego muy lento hasta que este blanda, alrededor de 2 horas y 1/2.','Alergias:\n
Laurel','N/A');
INSERT INTO `comidas` VALUES ('Pollo Con Almendras','pollo_con_almendras.gif','Ingredientes:\n
2 pechugas de pollo
100 g de almendras crudas
1 zanahoria
1 cebolla
1 pimiento verde
3-4 setas ostra (opcional)
2 dientes de ajo
1 cucharadita de jengibre fresco rallado (puede ser en polvo)
200 ml de caldo de pollo
2 cucharadas de salsa de soja
2 cucharadas de vino tinto
2 cucharadas de salsa de ostras (opcional)
Aceite de girasol o vegetal','\n\nPreparacion:

Trocee el pollo| pele y pique los ajos| ralle el jengibre fresco y corte en juliana el pimiento| la cebolla| la zanahoria y las setas.

Caliente una sarten antiadherente o wok a fuego fuerte con un chorrito de aceite. Todo lo que va a cocinar a partir de ahora| lo hara removiendo constantemente.

Incorpore el pollo a la sarten y saltee hasta que se tueste ligeramente y reservelas en un plato para mas tarde.

Saltee las almendras hasta tostarlas y reservelas junto al pollo.

En la misma sarten| agregue un chorrito de aceite nuevamente| si fuera necesario. Saltee el ajo y el jengibre un minuto y enseguida agregue el resto de las verduras.

Cuando las verduras esten hechas| incorpore el pollo junto a las almendras. Revuelva y agregue el vino tinto| la salsa de ostras y la salsa de soja.

Vierta el caldo de pollo en la sarten y cocine hasta que se consuma la mayor parte y la salsa resultante final se espese.','Alergias:\n
Almendras','N/A');
INSERT INTO `comidas` VALUES ('Pollo Frito','pollo_frito.gif','Ingredientes:\n
1 kg de alitas de pollo
1 taza de harina de trigo
2 tazas de pan rallado o molido
1 cucharadita de las especias que elijas (cayena o chile en polvo| pimienta negra molida| ajo y cebolla en polvo| paprika)
1 huevo
200 ml de leche
Sal y pimienta
Aceite para freir','\n\nPreparacion:

Corte las alitas del pollo. Con un cuchillo muy afilado cortelas por la articulacion. La puntillita que no sirve| retirelo. Sirve para hacer un caldo con ellas.
 
Prepare lo que sera el rebozado exterior. Ponga el huevo y la leche en un plato hondo y bata ambos ingredientes| hasta que quede una mezcla de color crema y sin grumos del huevo.

En otro plato prepare la otra parte del empanizado. Ponga la harina| el pan rallado| las especias y mezcle todos los ingredientes con las manos hasta que queden todos homogeneamente mezclados.

Pase las alitas por la mezcla de harina pan rallado y especias| despues por la mezcla del huevo y la leche y despues nuevamente por la mezcla de harina y pan rallado| que quede bien embadurnado de estos ingredientes. Reserve en un plato hasta haber terminado de empanar todas las alitas

Una vez empanadas| meta las alitas en la nevera durante una hora para que el empanado exterior se asiente bien.

Finalmente| ponga a freir las alitas en abundante aceite| durante unos 5 minutos. El aceite debe estar caliente| pero tampoco demasiado para que las alitas se frian bien en su interior sin que el empanizado exterior llegue a quemarse.','Alergias:\n
Gluten','N/A');
INSERT INTO `comidas` VALUES ('Pollo Frito Agridulce','pollo_frito_agridulce.gif','Ingredientes:\n
8 alitas de pollo
Una buena pizca de azucar blanco
Un chorro de vinagre o de vino blanco
Sal y pimienta
Aceite para feir','\n\nPreparacion:

Corte las alitas. Con un cuchillo bien afilado| cortelas por la parte de la articulacion. Se cortan muy facilmente. Despues| salpimiente.

En un sarten| ponga un chorrito de aceite suficiente para que tan solo cubra el fondo. Coloque aqui las alitas y frialas a fuego fuerte (no demasiado ya que| el aceite tiende a saltar muchisimo cuando se frien alitas de pollo).

Cuando ya esten fritas| baje el fuego y agregue una buena pizca de azucar. Puedes agregar mas o menos en funcion de lo potente que quiera la salsa. Revuelva y deje que se caramelice durante uno o dos minutos

Agregue el vinagre o el vino blanco. Deje cocinar 2 minutos mas antes de servir.','N/A','N/A');
INSERT INTO `comidas` VALUES ('Espagueti Con Carne','espagueti_con_carne.gif','Ingredientes:\n
400 g de espagueti
1 cebolla
2 zanahorias
1 hoja de apio
250 g de carne picada de cerdo
500 g de tomate natural triturado o 3 enteros (sin piel)
1/2 vaso de vino tinto o blanco
1/4 de vaso de leche
1 cucharadita de oregano
Sal y pimienta
Aceite de oliva','\n\nPreparacion:

Prepare la salsa. En un sarten grande coloque un chorrito de aceite de oliva y agregue el apio| la cebolla y la zanahoria picados muy finos. Salpimiente y cocine a fuego suave durante unos 10 minutos.
 
Cuando se hayan ablandado un poco| suba un poco el fuego y agregue la carne picada. Eche su parte de sal y pimienta y con una cuchara de palo| aplaste y corte| de tal forma que quede despues bien suelta| y disperse por toda la salsa.

Cuando la carne haya cogido color| agregue el tomate y la cucharadita de oregano. Deje cocinar unos 5 minutos mas.

Ahora| agregue el vino y despues la leche. El vino puede ser tinto o blanco. La leche le da un toque de cremosidad extra.

Deje cocinar a fuego medio hasta que quede una salsa muy densa durante unos 45 minutos. Esta salsa originalmente es asi pero si no la quiere tan espesa| puede dejarla un poco menos de tiempo.

10 minutos antes de que la salsa este cocinada| prepare los espaguetis. En un recipiente mas bien alto ponga abundante agua y sal.

Cuando este en ebullicion meta los espaguetis y dejelos cocinar hasta que esten al dente| durante alrededor de 10 minutos. Despues escurra el agua y sirva inmediatamente los espaguetis| con unas cucharadas de la salsa bolonhesa encima.','Alergias:\n
Lactosa','comida italiana');
INSERT INTO `comidas` VALUES ('Cerdo Agridulce','cerdo_agridulce.gif','Ingredientes:\n
400 g de carne de cerdo
150 g de harina de trigo
200 ml de cerveza
2 zanahorias
1 pimiento rojo
1 pimiento verde
1 cebolla
4 o 5 rodajas de pinha en conserva (su jugo lo reserva para la salsa agridulce)
Sal
Aceite

Para la salsa agridulce:
120 g de ketchup
60 g de azucar
1/2 vaso del jugo de la pinha
2 cucharadas de vinagre blanco
2 cucharadas de salsa de soja
1 cucharadita de maizena','\n\nPreparacion:

Corte la carnga de cerdo en dados grandes y salpimiente.

En un bol| ponga la harina y la cerveza. Agregue una pizca de sal y mezcle con un tengador. Debe quedar una mezcla liquida. Meta aqui los trozos del cerdo y empapelos bien con esta mezcla.

Ponga a freir el cerdo ya empapado en abundante aceite. Es mejor hacerlo en pequenhas tandas para que el aceite no se enfrie. Reserve el cerdo ya frito sobre papel absorbente.

En un wok o en un sarten grande| ponga primeramente la zanahoria cortada tambien en trozos grandes. Cocinela a fuego fuerte durante unos tres minutos.

Ahora agregue el resto de verdura. Agregue los pimientos y la cebolla| tambien cortadas en trozos grandes. La pinha no la agregue aun. Siga cocinando durante unos 5 minutos mas. Siempre a fuego fuerte y removiendo cada poco.

Mientras se cocina la verdura prepare la salsa agridulce. En una cazuelita ponga el ketchup| el azucar| el 1/2 vaso del jugo de pinha| el vinagre blanco| la salsa de soja y la maizena. Caliente la salsa e integre todos los ingredientes| removiendo con una cuchara. No es necesario cocinarla mas.

Cuando tenga la verdura algo hecha agregue su parte de sal. Agregue tambien la salsa de soja| los trozos de cerdo y la pinha| tambien cortada en trozos grandes. Deje cocinar 5 minutos mes| removiendo constantemente| antes de servir.','Alergias:\n
Gluten','N/A');
INSERT INTO `comidas` VALUES ('Lomo Al Horno','lomo_al_horno.gif','Ingredientes:\n
Una cinta de lomo de cerdo de alrededor de 1.5 kg
4 dientes de ajo
Una cucharadita de tomillo
Una cucharadita de pimenton dulce
Una cucharadita de romero
Sal y pimienta
Un chorrito de aceite de oliva','\n\nPreparacion:

Lo primero es preparar un majao. Ponga en un mortero el tomillo| el romero| el pimenton dulce| el ajo troceado y un chorrito de aceite de oliva. Aplaste hasta que quede todo integrado.
 
Ponga un trozo grande de papel de aluminio sobre una bandeja de horno. Encima coloque el lomo sin trocear. Ahora| con la ayuda de una cuchara| coloque el majao sobre el lomo de modo que lo cubra bien. Despues| ponga encima sal y pimienta.

Cierre y tape el lomo con el papel aluminio.

Meta la bandeja con el lomo tapado al horno| precalentado a 200ºC. En unos 45 minutos estara cocinado.

Saque y deje que repose 5 minutos. Despues| quite el papel de aluminio| trinche en rodajas finas y disfrute.','Alergias:\n
Tomillo','N/A');
INSERT INTO `comidas` VALUES ('Chop Suey','chop_suey.gif','Ingredientes:\n
12 camarones grandes pelados
8 cebollitas cambray partidas por la mitad
1 1/2 azas de brocoli troceado
1 taza de apio rebanado
2 tazas de germen de soya
4 cucharadas de salsa de soya
2 cucharadas de jugo de limon amarillo
1/2 cucharadita de jengibre picado finamente
2 cucharadas de mirin
1 cucharada de aceite','\n\nPreparacion:

Salpimiente los camarones y aselos en una sarten a fuego alto con el aceite. Cuando esten cocidos| retire del sarten y reserve.

Blanquee el germen de soya en agua hirviendo con sal por un minuto. Retire a un bannho de agua con hielo y repita el procedimiento con los brocolis.

Ase las cebollitas en una sarten a fuego alto hasta que doren.

En un tazon amplio| mezcle la soya con el jugo de limoon| el jengibre y el mirin. Agregue todos los ingredientes| revuelva| salpimienta y sirva. ','Alergias:\n
Mariscos','comida asiatica');
COMMIT;
