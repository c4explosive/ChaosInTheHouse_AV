import Tkinter as tk
import ttk
import sqlite3 as sql
from swiplclient import Prolog 
import os
import ScrolledText
import datetime as dt
cwdimg = os.getcwd() + '\\img\\'
cwdico = os.getcwd() + '\\ico\\'

class Chefex_Gui(object):
 
    #Este def es el constructor de clases en python, __init__
    def __init__(self, parent):
        #configuraciones iniciales
        print 'Loading views...'
        self.perfil_sel = 'sin perfil'
        self.perfil_sel_prefs = ''
        self.perfil_sel_allergies = ''
        self.main_frm = parent
        self.main_frm.focus_force()
        self.main_frm.title("Main frame")
        self.main_frm.configure(background='white')
        self.frame = tk.Frame(parent)
        self.frame.pack()
        self.main_frm.wm_title("Chefex")
        self.main_frm.iconbitmap(r""+cwdico + 'ap_chefex.ico')
        self.main_frm.geometry("1200x600+100+50")
        self.main_frm.resizable(width=False, height=False)
        #obtener el perfil seleccionado
        self.db_select_perfil()
        #lables
        tk.Label(self.main_frm, text="Chefex - Food Expert System", font=('courier, 44'), background='white').pack()
        chefex_logo = tk.PhotoImage(file = cwdimg + "ap_chefex_logo.gif")
        chefex_img = tk.Label(self.main_frm, image = chefex_logo, borderwidth=0, highlightthickness=0)
        chefex_img.image = chefex_logo
        chefex_img.place(x=380, y=100)
        #buttons
        tk.Button(text="Perfil", command =self.perfil_frm, font=('courier, 22'), background='white', relief=tk.SOLID ).place(x=220, y=300)
        tk.Button(text="Elegir Comida", command=self.getfood_frm, font=('courier, 22'), background='white', relief=tk.SOLID).place(x=483, y=300)
        tk.Button(text="Historial", command =self.histo_frm, font=('courier, 22'), background='white', relief=tk.SOLID).place(x=845, y=300)
        tk.Button(text="Salir", command=self.main_frm.destroy, font=('courier, 22'), background='white', relief=tk.SOLID).place(x=550, y=450)
 
    #---------------Metodo para esconder main_frm-------------------------#
    
    def hide_main(self):
        
        self.main_frm.withdraw()
 
    #---------------Mostramos la ventana de obtener comida----------------#
    
    def getfood_frm(self):
        
        self.hide_main()
        self.getfood = tk.Toplevel()
        self.getfood.focus_force()
        self.getfood.geometry("1200x600+100+50")
        self.getfood.configure(background='white')
        self.getfood.title("Chefex - Escoger Comida")
        self.getfood.iconbitmap(r""+cwdico + 'ap_chefex.ico')
        self.getfood.resizable(width=False, height=False)
        tk.Label(self.getfood, text="Escoge tus antojos", font=('courier, 22'), background='white').pack()
        
        #------rbtns-------#
        
        self.saborbtndef = tk.StringVar()
        self.saborbtndef.set(0)
        
        sabor_cont = tk.Frame(self.getfood, bd=16, background='white')
        tk.Label(sabor_cont, text="Sabor", font=('courier, 14'), background='white').pack(anchor=tk.W)
        #sabor_cont.pack(anchor=tk.W,pady=5, side="left", expand=1)
        sabor_cont.place(x=120,y=100)
        sabor = [
            ("Salado", "salado"),
            ("Picante", "picante"),
            ("Agrio", "agrio"),
            ("Dulce", "dulce"),
            ("N/A", "n/a")
        ]
        
        self.tempbtndef = tk.StringVar()
        self.tempbtndef.set(0)
        temp_cont = tk.Frame(self.getfood, bd=16, background='white')
        tk.Label(temp_cont, text="Temp", font=('courier, 14'), background='white').pack(anchor=tk.W)
        temp_cont.place(x=320,y=100)
        temp = [
            ("Frio", "frio"),
            ("Caliente", "caliente"),
            ("Tibio", "tibio"),
            ("N/A", "n/a")
        ]
        self.statebtndef = tk.StringVar()
        self.statebtndef.set(0)
        state_cont = tk.Frame(self.getfood,bd=16, background='white')
        tk.Label(state_cont, text="Estado", font=('courier, 14'), background='white').pack(anchor=tk.W)
        state_cont.place(x=520,y=100)
        estado = [
            ("Solido", "solido"),
            ("Blando", "blando"),
            ("Liquido", "liquido"),
            ("Mixto", "mixto"),
            ("N/A", "n/a")
        ]
        
        self.fitbtndef = tk.StringVar()
        self.fitbtndef.set(0)
        fit_cont = tk.Frame(self.getfood, bd=16, background='white')
        tk.Label(fit_cont, text="Grado de Fitness", font=('courier, 14'), background='white').pack(anchor=tk.W)
        fit_cont.place(x=720,y=100)
        fitness = [
            ("Saludable", "saludable"),
            ("Regular", "regular"),
            ("Ignorar", "ignorar"),
            ("N/A", "n/a")
        ]
        '''self.timebtndef = tk.StringVar()
        self.timebtndef.set(0)
        time_cont = tk.Frame(self.getfood, bd=16)
        tk.Label(time_cont, text="Tiempo").pack(anchor=tk.W)
        time_cont.pack(anchor=tk.W, pady=5, side="left", expand=1)
        tiempo = [
            ("<5min", "me5"),
            ("<15min", "me15"),
            (">15min", "ma15"),
            ("N/A", "n/a")
        ]'''
        self.platobtndef = tk.StringVar()
        self.platobtndef.set(0)
        plato_cont = tk.Frame(self.getfood, bd=16, background='white')
        tk.Label(plato_cont, text="Tipo de Plato", font=('courier, 14'), background='white').pack(anchor=tk.W)
        plato_cont.place(x=920,y=100)
        plato = [
            ("Plato Fuerte", "fuerte"),
            ("Guarnicion", "guarnicion"),
            ("Bebida", "bebida"),
            ("Batido", "batido"),
            ("Postre", "postre"),
            ("Snack", "snack"),
            ("N/A", "n/a")
        ]
        for k, v in sabor:
            tk.Radiobutton(sabor_cont,
            text=k,
            padx= 10,
            background='white',
            font=('courier, 12'),
            variable=self.saborbtndef,
            value=v).pack(anchor=tk.W)
        
        for k, v in temp:
            tk.Radiobutton(temp_cont,
            text=k,
            padx= 10,
            background='white',
            font=('courier, 12'),
            variable=self.tempbtndef,
            value=v).pack(anchor=tk.W)
            
        for k, v in estado:
            tk.Radiobutton(state_cont,
            text=k,
            padx= 10,
            background='white',
            font=('courier, 12'),
            variable=self.statebtndef,
            value=v).pack(anchor=tk.W)
            
        for k, v in fitness:
            tk.Radiobutton(fit_cont,
            text=k,
            padx= 10,
            background='white',
            font=('courier, 12'),
            variable=self.fitbtndef,
            value=v).pack(anchor=tk.W)
            
        '''for k, v in tiempo:
            tk.Radiobutton(time_cont,
            text=k,
            padx= 10,
            variable=self.timebtndef,
            value=v).pack(anchor=tk.W)'''
        for k, v in plato:
            tk.Radiobutton(plato_cont,
            text=k,
            padx= 10,
            background='white',
            font=('courier, 12'),
            variable=self.platobtndef,
            value=v).pack(anchor=tk.W)
        volver = lambda: self.close_frame(self.getfood, True)
        tk.Button(self.getfood, text="Volver", command=volver, font=('courier, 22'), background='white', relief=tk.SOLID).place(x=300, y=500)
        escoger = lambda: self.chefex_decide(
            self.saborbtndef.get(),
            self.tempbtndef.get(), 
            self.statebtndef.get(),
            self.fitbtndef.get(), 
            self.platobtndef.get()
            #self.timebtndef.get() 
        )
        tk.Button(self.getfood, text="Escoger Comida", command=escoger, font=('courier, 22'), background='white', relief=tk.SOLID).place(x=600, y=500)
    
    #---------------Ventana de Resultados----------------------------------#
    
    def getfood_res_frm(self):
        
        self.close_frame(self.getfood, False)
        getfood_res_frm = tk.Toplevel()
        getfood_res_frm.focus_force()
        getfood_res_frm.configure(background='white')
        getfood_res_frm.geometry("1200x600+100+50")
        getfood_res_frm.title("Chefex - Resultados")
        getfood_res_frm.iconbitmap(r""+cwdico + 'ap_chefex.ico')
        getfood_res_frm.resizable(width=False, height=False)
       
        tk.Label(getfood_res_frm, text="Resultados", font=('courier, 18'), background='white').pack()
        #hacer algo con los datos captados via prolg -------#
        '''tk.Label(getfood_res_frm, text=self.saborbtndef.get()).pack()
        tk.Label(getfood_res_frm, text=self.tempbtndef.get()).pack()
        tk.Label(getfood_res_frm, text=self.statebtndef.get()).pack()
        tk.Label(getfood_res_frm, text=self.fitbtndef.get()).pack()
        tk.Label(getfood_res_frm, text=self.timebtndef.get()).pack()'''
        x=0

        opciones = []
        datos_opciones = []

        '''lbl_nombre = tk.Label()
        lbl_nombre2 = tk.Label()
        lbl_nombre3 = tk.Label()

        lbl_img = tk.Label()
        lbl_img2 = tk.Label()
        lbl_img3 = tk.Label()

        text_ingr = ScrolledText.ScrolledText()
        text_ingr2 = ScrolledText.ScrolledText()
        text_ingr3 = ScrolledText.ScrolledText()'''

        logo = 0
        logo2 = 0 
        logo3 = 0
        for i, j in enumerate(self.comida):
            opciones.append(self.db_get_comidas(j))

            x += 1
            print 'Chosen food from list:', j
            
            if i == 2: 
                break
        for i, j in enumerate(opciones):

            #print 'food putting', j
            if i == 0:
                try:
                    datos_opciones = tuple(j)
                    #print datos_opciones
                    print cwdimg + ((datos_opciones[0].split(","))[1]).strip()
                    logo = tk.PhotoImage(file= cwdimg + ((datos_opciones[0].split(","))[1]).strip() ) 
                    lbl_nombre = tk.Label(getfood_res_frm, text=(datos_opciones[0].split(","))[0], font=('courier, 14'), background='white')
                    lbl_img = tk.Label(getfood_res_frm, image = logo, borderwidth=0, highlightthickness=0)
                    lbl_img.image = logo 
                    
                    text_ingr = ScrolledText.ScrolledText(getfood_res_frm, wrap=tk.WORD, width=29, height=10)
                    text_ingr.insert(tk.INSERT, ( (datos_opciones[0].split(","))[2] ).replace('|', ',') ) 
                    text_ingr.insert(tk.INSERT, ( (datos_opciones[0].split(","))[3]).replace('|', ',') )

                    lbl_nombre.place(x=215, y=30)
                    lbl_img.place(x=160, y=60)
                    text_ingr.place(x=160, y=320)
                    escoger1 = lambda: self.db_create_histo(getfood_res_frm, self.perfil_sel, lbl_nombre.cget("text"))
                    btn1 = tk.Button(getfood_res_frm, text="Elegir " + lbl_nombre.cget("text") + " y Terminar", command=escoger1, font=('courier, 12'), background='white', relief=tk.SOLID)
                    btn1.place(x=175, y=500)

                    if (i+1) == x:
                        break
                except Exception as e:
                    print 'Error Exception 1:', e
                

            if i == 1:
                try:
                    datos_opciones = tuple(j)
                    print cwdimg + ((datos_opciones[0].split(","))[1]).strip()
                    logo2 = tk.PhotoImage(file= cwdimg + ((datos_opciones[0].split(","))[1]).strip() ) 
                    lbl_nombre2 = tk.Label(getfood_res_frm, text=(datos_opciones[0].split(","))[0], font=('courier, 14'), background='white')

                    lbl_img2 = tk.Label(getfood_res_frm, image = logo2, borderwidth=0, highlightthickness=0)
                    lbl_img2.image = logo2
                   
                    text_ingr2 = ScrolledText.ScrolledText(getfood_res_frm, wrap=tk.WORD, width=29, height=10)
                    text_ingr2.insert(tk.INSERT, ( (datos_opciones[0].split(","))[2] ).replace('|', ',') ) 
                    text_ingr2.insert(tk.INSERT, ( (datos_opciones[0].split(","))[3]).replace('|', ',') )

                    lbl_nombre2.place(x=547, y=30)
                    lbl_img2.place(x=480, y=60)
                    text_ingr2.place(x=480, y=320)

                    escoger2 = lambda: self.db_create_histo(getfood_res_frm, self.perfil_sel ,lbl_nombre2.cget("text"))
                    btn2 = tk.Button(getfood_res_frm, text="Elegir " + lbl_nombre2.cget("text") + " y Terminar", 
                        command=escoger2, font=('courier, 12'), background='white', relief=tk.SOLID)
                    btn2.place(x=495, y=500)

                    if (i+1) == x:
                        break
                except Exception as e:
                    print 'Error Exception 2:', e
                
            if i == 2:
                try:
                    datos_opciones = tuple(j)
                    print cwdimg + ((datos_opciones[0].split(","))[1]).strip()
                    logo3 = tk.PhotoImage(file= cwdimg + ((datos_opciones[0].split(","))[1]).strip() ) 
                    lbl_nombre3 = tk.Label(getfood_res_frm, text=(datos_opciones[0].split(","))[0], font=('courier, 14'), background='white')

                    lbl_img3 = tk.Label(getfood_res_frm, image = logo3, borderwidth=0, highlightthickness=0)
                    lbl_img3.image = logo3
                    
                    text_ingr3 = ScrolledText.ScrolledText(getfood_res_frm, wrap=tk.WORD, width=29, height=10)
                    text_ingr3.insert(tk.INSERT, ( (datos_opciones[0].split(","))[2] ).replace('|', ',') ) 
                    text_ingr3.insert(tk.INSERT, ( (datos_opciones[0].split(","))[3]).replace('|', ',') )
                    
                    lbl_nombre3.place(x=870, y=30)
                    lbl_img3.place(x=800, y=60)
                    text_ingr3.place(x=800, y=320)
                    escoger3 = lambda: self.db_create_histo(getfood_res_frm, self.perfil_sel, lbl_nombre3.cget("text"))
                    btn3 = tk.Button(getfood_res_frm, text="Elegir " + lbl_nombre3.cget("text") + " y Terminar", 
                        command=escoger3, font=('courier, 12'), background='white', relief=tk.SOLID)
                    btn3.place(x=810, y=500)

                    if (i+1) == x:
                        break
                except Exception as e:
                    print 'Error Exception 3:', e
                
        
        volver = lambda: self.close_frame(getfood_res_frm, True)
        tk.Button(getfood_res_frm, text="Volver", command=volver, font=('courier, 12'), background='white', relief=tk.SOLID).pack(side="bottom", pady=20) 
        #print lbl_nombre.cget("text"), lbl_nombre2.cget("text"),lbl_nombre3.cget("text")
        
        
    #---------------Ventana para perfil------------------------------------#
    
    def perfil_frm(self):
        
        self.hide_main()
        perfil = tk.Toplevel()
        perfil.focus_force()
        perfil.geometry("1200x600+100+50")
        perfil.title("Chefex - Perfil")
        perfil.configure(background='white')
        perfil.iconbitmap(r""+cwdico + 'ap_chefex.ico')
        perfil.resizable(width=False, height=False)
        tk.Label(perfil, text="Perfil", font=('courier, 22'), background='white').pack()
        
        #------------Agregar prefs--------------------#
        tk.Label(perfil, text="Crear un perfil", font=('courier, 18'), background='white').place(x=200, y=100)
        tk.Label(perfil, text="Nombre", font=('courier, 14'), background='white').place(x=200, y=150)
        perfil_nombre = tk.Entry(perfil, relief=tk.SOLID, width=30)
        perfil_nombre.place(x=200, y=200)
        tk.Label(perfil, text="Preferencias", font=('courier, 14'), background='white').place(x=200, y=250)
        #perfil_prefs = tk.Entry(perfil, width=30)
        self.perfil_prefs_cbox = ttk.Combobox(perfil, state='readonly')
        self.perfil_prefs_cbox.place(x=680, y=170)
        self.perfil_prefs_cbox['values'] = ['Comida Americana', 'Comida Criolla', 'Comida Italiana', 'Comida Asiatica', 'Comida Francesa', 'Comida Espanhola']
        #perfil_prefs.place(x=200, y=300)
        self.perfil_prefs_cbox.place(x=200, y=300)
        tk.Label(perfil, text="Alergias", font=('courier, 14'), background='white').place(x=200, y=350)
        perfil_alergias = tk.Entry(perfil, relief=tk.SOLID, width=30)
        perfil_alergias.place(x=200, y=400)
        agregar = lambda: self.db_create_perfil(perfil, perfil_nombre.get(), self.perfil_prefs_cbox.get(), perfil_alergias.get()) 
        tk.Button(perfil, text="Agregar Perfil", command=agregar, font=('courier, 14'), background='white', relief=tk.SOLID).place(x=200, y=450)
        
        #------------Borrar prefs---------------------#
        self.perfil_lbl_txtVar = tk.StringVar()
        self.perfil_lbl_txtVar.set("Perfil Actual: " + self.perfil_sel)
        self.perfil_lbl = tk.Label(perfil, textvariable=self.perfil_lbl_txtVar, font=('courier, 18'), background='white').place(x=650, y=100)
        #cbox para seleccionar
        self.perfil_cbox = ttk.Combobox(perfil, state='readonly')
        self.perfil_cbox.place(x=680, y=170)
        self.perfil_cbox['values'] = self.db_get_perfil()
        seleccionar = lambda: self.update_perfil()
        borrar = lambda: self.db_delete_perfil()
        tk.Button(perfil, text="Seleccionar Perfil", command=seleccionar, font=('courier, 14'), background='white',relief=tk.SOLID).place(x=600, y=250)
        tk.Button(perfil, text="Borrar Perfil", command=borrar, font=('courier, 14'), background='white', relief=tk.SOLID).place(x=800, y=250)
        
        #-----------Volver----------------------------#
        
        volver = lambda: self.close_frame(perfil, True)
        tk.Button(perfil, text="Volver", command=volver, font=('courier, 22'), background='white', relief=tk.SOLID).pack(side="bottom", pady=40)
    
    #---------------Ventana de historial de comidas escogidas--------------#
    
    def histo_frm(self):
        self.hide_main()
        histo = tk.Toplevel()
        histo.geometry("1200x600+100+50")
        histo.configure(background='white')
        histo.focus_force()
        histo.title("Chefex - Historial")
        histo.iconbitmap(r""+cwdico + 'ap_chefex.ico')
        histo.resizable(width=False, height=False)
        tk.Label(histo, text="Historial", font=('courier, 22'), background='white').pack(pady=10)
        #--------------Mostrar historial -----------------#
        for i in self.db_get_histo():
            print i
            tk.Label(histo, text=i, font=('courier, 14'), background='white').pack()
            
        volver = lambda: self.close_frame(histo, True)
        tk.Button(histo, text="Volver", command=volver, font=('courier, 22'), background='white', relief=tk.SOLID).pack(side="bottom", pady=40)
        
    #---------------Cerramos la ventana que enviemos-----------------------#
    
    def close_frame(self, target_frame, cond):
        
        target_frame.destroy()
        if cond == True: self.show_main()
 
    #-----------------Mostramos nuestra window principal-------------------#
    
    def show_main(self):
        
        self.main_frm.update()
        self.main_frm.deiconify()
    
    def db_create_perfil(self, perfil, name, prefs, aller):
        
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            c.execute("INSERT INTO users VALUES (?,?,?,?)", (name, prefs, aller, 0))
            conn.commit()
            conn.close()
            self.perfil_cbox['values'] = self.db_get_perfil()
        except Exception as e:
            print 'Error Exception->CREATE->PRF:', e
            conn.close()
            self.perfil_cbox['values'] = self.db_get_perfil()
        
    
    def db_create_histo(self, getfood_res_frm, perfname, food):
        
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            print food
            c.execute("INSERT INTO histo VALUES (?, ?, ?)", (perfname, food, dt.datetime.now().date()))
            conn.commit()
        except Exception as e:
            print 'Error Exception->CREATE->HIST:', e
            conn.close()
            self.close_frame(getfood_res_frm, True)
            self.show_main
        

    def db_delete_perfil(self):
        try:
            name = self.perfil_cbox.get()
            if (name == self.perfil_sel):
                self.perfil_sel = 'sin perfil'
                self.perfil_sel_prefs = ''
                self.perfil_sel_allergies = ''
                self.perfil_lbl_txtVar.set('Perfil Actual: No seleccionado (sin perfil)')

            conn = sql.connect('chefex.db')
            c = conn.cursor()
            c.execute("DELETE FROM users WHERE name = ?", (name,))
            conn.commit()
            conn.close()
            self.perfil_cbox.set('')
            self.perfil_cbox['values'] = self.db_get_perfil()
        except Exception as e:
            print 'Error Exception->DELETE->PRF:', e
        
        print 'db_delete_perfil->Perfil Seleccionado:', self.perfil_sel, '\nPrefs:', self.perfil_sel_prefs, '\nAllergies:', self.perfil_sel_allergies
        
    def db_update_perfil(self):
        
        try:
            name = self.perfil_cbox.get()
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            c.execute("UPDATE users SET sel = ? WHERE sel = ?", (0,1))
            c.execute("UPDATE users SET name = ?, sel = ? WHERE name = ?", (name, 1, name))
            conn.commit()
            conn.close()
            self.db_select_perfil()
        except Exception as e:
            print 'Error Exception->UPDATE->PRF:', e
            conn.close()
            self.db_select_perfil()
        

    def update_perfil(self):
        
        self.db_update_perfil()
        self.perfil_lbl_txtVar.set("Perfil Actual: " + self.perfil_sel)

    def db_get_perfil(self):
        
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            c.execute("SELECT name FROM users")
            perfiles = c.fetchall()
            conn.commit()
            conn.close()
            lista = []
            for i in perfiles:
                lista.append(i[0])
                
            return lista
        except Exception as e:
            print 'Error Exception->READ->PRF:', e
        

    def db_select_perfil(self):
        
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            #nomobre de perfil
            c.execute("SELECT name FROM users WHERE sel=1")
            perfil = c.fetchone()
            if perfil != None:
                self.perfil_sel = [(str(i).encode('utf-8')).replace('[','').replace(']', '') for i in perfil][0]
                #preferencias
                c.execute("SELECT prefs FROM users WHERE sel=1")
                perfil = c.fetchone()
                self.perfil_sel_prefs = [(str(i).encode('utf-8')).replace('[','').replace(']', '') for i in perfil][0]
                #alergias
                c.execute("SELECT allergies FROM users WHERE sel=1")
                perfil = c.fetchone()
                self.perfil_sel_allergies = [(str(i).encode('utf-8')).replace('[','').replace(']', '') for i in perfil][0]
                #self.perfil_sel = str(perfil).encode('ascii', 'ignore')
            conn.commit()
            conn.close()
            print 'db_select_perfil->Perfil seleccionado:\nNombre:', self.perfil_sel , '\nPrefs:', self.perfil_sel_prefs, '\nAllergies:', self.perfil_sel_allergies, '\n'      
            
            return perfil
        except Exception as e:
            conn.close()
            print 'Error Exception->READ->PRF->ID:', e
        
    def db_get_histo(self):
        
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            c.execute("SELECT * FROM histo")
            perfiles = c.fetchall()
            conn.commit()
            conn.close()
            lista = []
            for i in perfiles:
                lista.append(i)
                
            return lista
        except Exception as e:
            conn.close()
            print 'Error Exception->READ->HIST:', e
        

    def db_get_comidas(self, nombre_comida):
        
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            c.execute("SELECT nombre, dir_imagen, ingredientes, prep, alergias, caracteristicas FROM comidas WHERE nombre = ?", (nombre_comida,))
            res_comidas = c.fetchall()
            conn.commit()
            conn.close()
            lista = []
            for i in res_comidas:
                lista.append(i)
            #formatiamos utf-8, u'
            lista = [[(str(i).encode('utf-8')) for i in j] for j in lista] 
            #tratamiento de cadenas para la presentacion y busqueda sanitada en la bd
            lista = [((((str(i).replace('[', '')).replace(']', '')).replace("'", "")).replace('\\n','\n')).replace('\\', '') for i in lista ] 
            #print "\nLista de comidas extraidas:", lista
            return lista
        except Exception as e:
            conn.close()
            print 'Error Exception->READ->FOOD:', e
        
        
    def chefex_decide(self, sabor, temp, estado, fit, plato): #tiempo
        
        comidacrit = []
        self.comida = {}
        if sabor == 'salado': comidacrit.append("comida_salada(X)") 
        elif sabor == 'picante': comidacrit.append("comida_picante(X)") 
        elif sabor == 'agrio': comidacrit.append("comida_agria(X)") 
        elif sabor == 'dulce': comidacrit.append("comida_dulce(X)") 
        elif sabor == 'n/a': pass
        elif sabor == '0': pass
        elif sabor == 0: pass
        
        if temp == 'caliente': comidacrit.append("comida_caliente(X)") 
        elif temp == 'frio': comidacrit.append("comida_fria(X)") 
        elif temp == 'tibio': comidacrit.append("comida_tibia(X)") 
        elif temp == 'n/a': pass
        elif temp == '0': pass
        elif temp == 0: pass
        
        if estado == 'solido': comidacrit.append("comida_solida(X)") 
        elif estado == 'blando': comidacrit.append("comida_suave(X)") 
        elif estado == 'liquido': comidacrit.append("comida_liquida(X)") 
        elif estado == 'mixto': comidacrit.append("comida_mixta(X)") 
        elif estado == 'n/a': pass
        elif estado == '0': pass
        elif estado == 0: pass
        
        if fit == 'saludable': comidacrit.append("comida_saludable(X)") 
        elif fit == 'regular': comidacrit.append("comida_regular(X)") 
        elif fit == 'ignorar': comidacrit.append("comida_ignora(X)") 
        elif fit == 'n/a': pass 
        elif fit == '0': pass
        elif fit == 0: pass 
        
        '''if tiempo == 'me5': comidacrit.append("comida_rapida(X)") 
        elif tiempo == 'me15': comidacrit.append("comida_media(X)") 
        elif tiempo == 'ma15': comidacrit.append("comida_lenta(X)") 
        elif tiempo == 'n/a': pass
        elif tiempo == '0': pass
        elif tiempo == 0: pass'''
        if plato == 'fuerte': comidacrit.append("comida_fuerte(X)") 
        elif plato == 'guarnicion': comidacrit.append("comida_guarnicion(X)") 
        elif plato == 'bebida': comidacrit.append("comida_bebida(X)") 
        elif plato == 'batido': comidacrit.append("comida_batido(X)") 
        elif plato == 'postre': comidacrit.append("comida_postre(X)") 
        elif plato == 'snack': comidacrit.append("comida_snack(X)") 
        elif plato == 'n/a': pass
        elif plato == '0': pass
        elif plato == 0: pass
        plquery = ','.join(map(str, comidacrit))
        #plquery += '.'
        self.comida = self.chefex_kbi(plquery)
        self.getfood_res_frm()
        
    def chefex_kbi(self, plquery):
        try:
            PL_HOST = "localhost"
            PL_PORT = 3000
            PL_PASSWORD = "Kappa1Krey3"
            print "\nQuery:", plquery
            prolog = Prolog(PL_HOST, PL_PORT, PL_PASSWORD)  
            
            res = []
            c = 0
            for i in prolog.query(plquery):
                if i.values() not in res:
                    res.append(i.values())
            
            #formatiamos utf-8, u'
            res = [[(str(i).encode('utf-8')).split() for i in j] for j in res] 
            #tratamiento de cadenas para la presentacion y busqueda sanitada en la bd
            res = [((((str(i).replace('[', '')).replace(']', '')).replace('_', ' ')).replace("'", "")).title() for i in res ] 
            remlist = []
            print '\nCurrent food list:', res
            for k in res:
                
                print '\nAnalizing Food:', k
                if (not self.kbi_get_likes_from_db(k)):
                    print 'Removing: ', k, 'Reason: not compatible with Prefs'
                    if k not in remlist:
                        remlist.append(k)
               
                if (not self.kbi_get_dislikes_from_db(k)):
                    print 'Removing: ', k, 'Reason: not compatible with Allergies'
                    if k not in remlist:
                        remlist.append(k)
            
            print '\nDeleting foods:\n'
            for k in remlist:
                try:
                    print 'Removed:', k, 'from list'
                    res.remove(k)
                except Exception as e:
                    print "Error Exception [on remove food]:", k
                

            print "\nFinal food list:", res, '\n'
            return res
        except Exception as e:
            print 'Error Exception->READ->KBI:', e
        

    def kbi_get_likes_from_db(self, comida_kbi):
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            #chequeamos preferencias y les damos prioridad
            if (self.perfil_sel_prefs != '' and self.perfil_sel_prefs != 'N/A'):

                prefs = ((self.perfil_sel_prefs).replace(' ', '')).split(',')
                print 'Evaluating->Prefs'
                for k in prefs:
                    c.execute( 'SELECT caracteristicas FROM comidas WHERE nombre = ? AND caracteristicas LIKE ("%" || ? || "%")', (comida_kbi, k,) )
                    ans = c.fetchone()
                    if (ans != 'None' and ans != None):
                        print 'Keeping:', comida_kbi, '= Target Pref:', ans, '[Against] Food Pref:', k
                        conn.commit()
                        conn.close()
                        return True
                    else:
                        print 'Incompatible food found:', comida_kbi, '= Target Pref:', ans, '[Against] Food Pref:', k
                        conn.commit()
                        conn.close()
                        return False        
            else:
                print 'No Preferences on Profile, skipping this filter...'
                conn.commit()
                conn.close()
                return True
        except Exception as e:
            conn.close()
            print 'Error Exception->READ->LIKES:', e
        

    def kbi_get_dislikes_from_db(self, comida_kbi):
        try:
            conn = sql.connect('chefex.db')
            c = conn.cursor()
            print 'Evaluating->Allergies'
            #chequeamos allergias y las quitamos de los resultados
            if (self.perfil_sel_allergies != '' and self.perfil_sel_allergies != 'N/A'):
                aller = ((self.perfil_sel_allergies).replace(' ', '')).split(',')
                for k in aller:
                    c.execute( 'SELECT alergias FROM comidas WHERE nombre = ? AND alergias LIKE ("%" || ? || "%")', (comida_kbi, k,) )
                    ans = c.fetchone()
                    if (ans != 'None' and ans != None):
                        print 'Incompatible food found:', comida_kbi, '= Target Allergy:', ans, '[Against] Food Allergy:', k
                        conn.commit()
                        conn.close()
                        return False
                    else:
                        print 'Keeping:', comida_kbi, '= Target Allergy:', ans, '[Against] Food Allergy:', k
                        conn.commit()
                        conn.close()
                        return True       
            else:
                print 'No Allergies on Profile, skipping this filter...'
                conn.commit()
                conn.close()
                return True
        except Exception as e:
            print 'Error Exception->READ->DISLIKES:', e
        
#-----------------------------------------------------------------#
if __name__ == "__main__": #Este script solo se ejectura si este es el main, osea el script "principal"
    main_frm = tk.Tk()
    #main_frm.geometry("1024x680")
    app = Chefex_Gui(main_frm)
    main_frm.mainloop()