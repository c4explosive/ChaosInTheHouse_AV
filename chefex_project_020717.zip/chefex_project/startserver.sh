#!/bin/sh

PL_PORT=3000
PL_PASSWORD="Kappa1Krey3"
PL_LOGFILE="chefexlog.txt"

swipl -f swipl-server.pl -g "start_server($PL_PORT, $PL_PASSWORD, '$PL_LOGFILE')" &
