:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/html_write)).
:- use_module(library(http/json)).
:- use_module(library(http/json_convert)).
:- use_module(library(http/http_json)).
:- use_module(library(http/http_log)).

:- http_handler(root(query), handle_query, []).
:- http_handler(root(add), handle_add, []).
:- http_handler(root(remove), handle_remove, []).
:- http_handler(root(shutdown), handle_shutdown, []).





http_json:json_type('application/json').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This command to start:

start_server(Port, Password, LogFile) :-
	server(Port, Password, LogFile),
	wait.

wait :- thread_get_message(_),
	halt.

server(Port, Password, LogFile) :-
	assert(password(Password)),
	http_server(http_dispatch, [port(Port)]),
	set_setting(http:logfile, LogFile).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

unpack(InProlog, OutTerm, OutBindings) :-
	InProlog = json( [action=Action, password=Password] ),
	password(Password),
	atom_to_term(Action, OutTerm, OutBindings).

read_json_request(InRequest, OutProlog) :-
	http_read_json(InRequest, JSON),
	json_to_prolog(JSON, OutProlog).

handle_add(Request) :-
	read_json_request(Request, Unpackable),
	unpack(Unpackable, Term, _),
	assert(Term),
	format(atom(StringResult), "~q", Term),
	reply_json( StringResult ).

handle_remove(Request) :-
	read_json_request(Request, Unpackable),
	unpack(Unpackable, Term, _),
	(
		(Term = _/_, abolish(Term)) ;
		retract(Term)
	),
	format(atom(StringResult), "~q", Term),
	reply_json( StringResult ).

jsonize(X, Y) :-
	Y = json( X ).

evaluate_query(InTerm, InBindings, OutStringResult) :-
	Goal =.. [findall, InBindings, InTerm, IR],
	call(Goal),
	sort(IR, Result),
	maplist(jsonize, Result, OutStringResult).

handle_query(Request) :-
	read_json_request(Request, Unpackable),
	unpack(Unpackable, Term, Bindings),
	evaluate_query(Term, Bindings, Result),
	reply_json(Result,
		[
			serialize_unknown(true)
		]).

handle_shutdown(Request) :-
	read_json_request(Request, Unpackable),
	unpack(Unpackable, Term, _),
	format(atom(StringResult), "~q", Term),
	reply_json( StringResult ),
	halt.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%La entrada de nuestra comida seran las reglas, esas reglas eligen nuestra comida*

%sabores
comida_salada(X):- salado(X).
comida_dulce(X):- dulce(X).
comida_agria(X):- agrio(X).
comida_picante(X):- picante(X).

%estados
comida_solida(X):- solido(X).
comida_liquida(X):- liquido(X).
comida_suave(X):- suave(X).
comida_mixta(X):- mixto(X).

%temperatura
comida_caliente(X):- caliente(X).
comida_tibia(X):- tibio(X).
comida_fresca(X):- fresco(X).
comida_fria(X):- frio(X).

%grado de fitness
comida_saludable(X):- fit(X).
comida_regular(X):- regular(X).
comida_ignora(X):- ignora(X).

%tiempo de prep ( ignorar )%
/*comida_rapida(X):- rapido(X).
comida_media(X):- medio(X).
comida_lenta(X):- lento(X).*/

%tipo de plato
comida_fuerte(X):- fuerte(X).
comida_guarnicion(X):- guarnicion(X).
comida_bebida(X):- bebida(X).
comida_batido(X):- batido(X).
comida_postre(X):- postre(X).
comida_snack(X):- snack(X).

/*--------------------------------------*
**										*
**				Sabor					*
**										*
**--------------------------------------*/

%facts de comidas saladas%

salado(sopa_de_pollo).
salado(popcorn_con_mantequilla).
salado(mani).
salado(papas_fritas).
salado(arroz_blanco).
salado(porotos_rojos).
salado(pollo_asado).
salado(paella_de_mariscos).
salado(pollo_al_ajillo).
salado(carne_guisada).
salado(albondigas).
salado(risotto_de_setas).
salado(lasagna).
salado(salmon_ahumado).
salado(arroz_con_pollo).
salado(carne_asada).
salado(pollo_con_almendras).
salado(pollo_frito).
salado(espagueti_con_carne).
salado(lomo_al_horno).
salado(chop_suey).

%facts de comidas dulces%

dulce(coca_cola).
dulce(frappe_de_chocolate).
dulce(pastel_de_chocolate).
dulce(helado_de_cookies_and_cream).
dulce(leche_con_chocolate).
dulce(smoothie_de_banana_y_fresa).
dulce(mousse_de_chocolate_blanco).
dulce(smoothie_de_papaya_y_chia).
dulce(pollo_frito_agridulce).
dulce(cerdo_agridulce).

%facts de comidas agria%

agrio(naranja).
agrio(limon).
agrio(smoothie_de_banana_y_fresa).
agrio(smoothie_de_frutos_rojos).
agrio(pollo_frito_agridulce).
agrio(cerdo_agridulce).


%facts de comidas picante%

picante(doritos_picantes).
picante(pollo_cajun).
picante(pollo_al_curry).
picante(pollo_a_la_naranja).

/*--------------------------------------*
**										*
**				Estado					*
**										*
**--------------------------------------*/

%facts de comidas mixta%

mixto(sopa_de_pollo).
mixto(helado_de_cookies_and_cream).
mixto(smoothie_de_banana_y_fresa).
mixto(smoothie_de_frutos_rojos).
mixto(carne_guisada).
mixto(albondigas).
mixto(smoothie_de_papaya_y_chia).

%facts de comidas suaves (blando)%

suave(popcorn_con_mantequilla).
suave(papas_fritas).
suave(arroz_blanco).
suave(porotos_rojos).
suave(pollo_asado).
suave(pastel_de_chocolate).
suave(pollo_cajun).
suave(paella_de_mariscos).
suave(pollo_al_curry).
suave(pollo_al_ajillo).
suave(pollo_a_la_naranja).
suave(ensalada_de_tomate).
suave(ensalada_caprese).
suave(mousse_de_chocolate_blanco).
suave(risotto_de_setas).
suave(lasagna).
suave(salmon_ahumado).
suave(arroz_con_pollo).
suave(carne_asada).
suave(pollo_con_almendras).
suave(pollo_frito).
suave(espagueti_con_carne).
suave(pollo_frito_agridulce).
suave(cerdo_agridulce).
suave(lomo_al_horno).
suave(chop_suey).

%facts de comidas solidas%

solido(mani).
solido(doritos_picantes).

%facts de comidas liquida%

liquido(coca_cola).
liquido(frappe_de_chocolate).
liquido(naranja).
liquido(limon).
liquido(leche_con_chocolate).
liquido(smoothie_de_banana_y_fresa).
liquido(smoothie_de_frutos_rojos).
liquido(smoothie_de_papaya_y_chia).

/*--------------------------------------*
**										*
**				Temperatura				*
**										*
**--------------------------------------*/

%facts de comidas calientes%

caliente(sopa_de_pollo).
caliente(popcorn_con_mantequilla).
caliente(papas_fritas).
caliente(paella_de_mariscos).
caliente(carne_guisada).
caliente(albondigas).
caliente(lasagna).
caliente(salmon_ahumado).
caliente(carne_asada).
caliente(espagueti_con_carne).
caliente(chop_suey).

%facts de comidas tibias%

tibio(arroz_blanco).
tibio(porotos_rojos).
tibio(pollo_asado).
tibio(pollo_cajun).
tibio(doritos_picantes).
tibio(pollo_al_curry).
tibio(pollo_al_ajillo).
tibio(pollo_a_la_naranja).
tibio(risotto_de_setas).
tibio(arroz_con_pollo).
tibio(pollo_con_almendras).
tibio(pollo_frito).
tibio(pollo_frito_agridulce).
tibio(cerdo_agridulce).
tibio(lomo_al_horno).

%facts de comidas fresca%

fresco(pastel_de_chocolate).
fresco(mani).
fresco(naranja).
fresco(limon).
fresco(smoothie_de_banana_y_fresa).
fresco(smoothie_de_frutos_rojos).
fresco(ensalada_de_tomate).
fresco(ensalada_caprese).
fresco(smoothie_de_papaya_y_chia).

%facts de comidas frias%

frio(coca_cola).
frio(frappe_de_chocolate).
frio(helado_de_cookies_and_cream).
frio(leche_con_chocolate).
frio(smoothie_de_banana_y_fresa).
frio(smoothie_de_frutos_rojos).
frio(mousse_de_chocolate_blanco).
frio(smoothie_de_papaya_y_chia).

/*--------------------------------------*
**										*
**			Grado de Fitness			*
**										*
**--------------------------------------*/

%facts de comidas regulares%

regular(sopa_de_pollo).
regular(popcorn_con_mantequilla).
regular(arroz_blanco).
regular(porotos_rojos).
regular(naranja).
regular(limon).
regular(leche_con_chocolate).
regular(smoothie_de_banana_y_fresa).
regular(paella_de_mariscos).
regular(pollo_al_curry).
regular(pollo_al_ajillo).
regular(pollo_a_la_naranja).
regular(ensalada_caprese).
regular(carne_guisada).
regular(albondigas).
regular(lasagna).
regular(arroz_con_pollo).
regular(carne_asada).
regular(pollo_con_almendras).
regular(pollo_frito).
regular(espagueti_con_carne).
regular(pollo_frito_agridulce).
regular(cerdo_agridulce).
regular(lomo_al_horno).
regular(chop_suey).

%facts de comidas fit%

fit(pollo_asado).
fit(pollo_cajun).
fit(mani).
fit(smoothie_de_frutos_rojos).
fit(ensalada_de_tomate).
fit(smoothie_de_papaya_y_chia).
fit(risotto_de_setas).
fit(salmon_ahumado).

%facts de comidas not fit%

ignora(papas_fritas).
ignora(coca_cola).
ignora(pastel_de_chocolate).
ignora(frappe_de_chocolate).
ignora(doritos_picantes).
ignora(helado_de_cookies_and_cream).
ignora(mousse_de_chocolate_blanco).

/*--------------------------------------*
**										*
**			Tipo de Plato				*
**										*
**--------------------------------------*/

%facts de comidas plato fuertes%

fuerte(pollo_asado).
fuerte(sopa_de_pollo).
fuerte(pollo_cajun).
fuerte(paella_de_mariscos).
fuerte(pollo_al_curry).
fuerte(pollo_al_ajillo).
fuerte(pollo_a_la_naranja).
fuerte(carne_guisada).
fuerte(albondigas).
fuerte(risotto_de_setas).
fuerte(lasagna).
fuerte(salmon_ahumado).
fuerte(arroz_con_pollo).
fuerte(carne_asada).
fuerte(pollo_con_almendras).
fuerte(pollo_frito).
fuerte(espagueti_con_carne).
fuerte(pollo_frito_agridulce).
fuerte(cerdo_agridulce).
fuerte(lomo_al_horno).
fuerte(chop_suey).

%facts de comidas plato guarnicion%

guarnicion(papas_fritas).
guarnicion(arroz_blanco).
guarnicion(porotos_rojos).
guarnicion(ensalada_de_tomate).
guarnicion(ensalada_caprese).
guarnicion(risotto_de_setas).

%facts de comidas que son bebidas%

bebida(coca_cola).
bebida(leche_con_chocolate).

%facts de comidas que son batidos%

batido(frappe_de_chocolate).
batido(smoothie_de_banana_y_fresa).
batido(smoothie_de_frutos_rojos).
batido(smoothie_de_papaya_y_chia).

%facts de comidas que son postres%

postre(pastel_de_chocolate).
postre(helado_de_cookies_and_cream).
postre(mousse_de_chocolate_blanco).

%facts de comidas que son snacks%

snack(popcorn_con_mantequilla).
snack(mani).
snack(naranja).
snack(limon).
snack(doritos_picantes).

















%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

/*--------------------------------------*
**										*
**		Tiempo (No se incluye)			*
**										*
**--------------------------------------*/
%facts de tiempo de prep%

/*medio(sopa).
rapido(popcorn).
rapido(mani).
medio(papas_fritas).
lento(arroz_porotos_pollo).
lento(arroz_porotos_pollo_soda).*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%