Requerimientos

Interprete de Python 2.7.13 (version estable) 
modulo Tkinter para python 
modulo ttk
modulo swiplclient
**Todos los modulos viene por default con python**
swiplclient esta incluido en la carpeta y tiene que estar en el mismo dir que el script principal (chefexgui.py)

Instalacion

Instalar python - https://www.python.org/downloads/
Alternativa - https://store.enthought.com/downloads/ (Pueden instalar modulos por medio de la interfaz)
Instalar los modulos por medio de pip - en la linea de comandos (cmd) introducir pip install x (nombre de modulo)

Ejecutar

1. Primero ejecutar el batch file 'startserver' el cual inicializa swipl-server
2. Ejecutar chefexgui.py desde el IDE de tu preferencia o en la linea de comando "python chefexgui.py"
3. Deberia servir sin problema, sino me preguntan. :)

IMPORTANTE: chefexgui.py necesita que la bd, el dir ico y img esten con el en el directorio base

